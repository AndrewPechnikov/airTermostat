// #include "ClockManager.h"

// ClockManager::ClockManager() : rtc(RTC_DS1302, A3, A2, A1) {}

// void ClockManager::begin() {
//     rtc.begin();
//     rtc.settime(0, 7, 11, 9, 4, 24, 2);
// }

// String ClockManager::getTime() {
//     return rtc.gettime("H:i:s");
// }
